import React from 'react'
import "./contact.css"
const contact = () => {
  return (
  <section id='contact'>contact</section>
  )
}

export default contact
